import requests
import bs4
#use request to fetch url
page=requests.get("https://www.365scores.com/ar/news/magazine/%D8%B3%D8%AC%D9%84-%D8%A7%D9%84%D9%87%D8%AF%D8%A7%D9%81%D9%8A%D9%86-%D8%A7%D9%84%D8%AA%D8%A7%D8%B1%D9%8A%D8%AE%D9%8A%D9%8A%D9%86-%D9%84%D9%83%D8%A3%D8%B3-%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85/")
#check if the page is found or not
if page.status_code==404:
    print("can't reach to page ")
#check if the page found now we now can scrap data
elif page.status_code==200:
    # save page content
    src = page.content
    #now we use bs4 library and send two para page content and html.parser to pull html code of the page
    soup = bs4.BeautifulSoup(src, "html.parser")

    # select all tr in the table
    table = soup.findAll("tr")
    print("                ترتيب هدافي كاس العالم منذ تاريخ بدء البطولة حتى الان                   ")
    print("                 ")

    for tr in table:
        td = tr.findAll("td")
        for td in tr:
            print("{:<15}".format(td.text), end="     |      ")
        print()

